# Weak Learning Failure Alone Is Not Gradient Starvation

This is the self-contained anonymous ICLR 2027 manuscript package prepared for
Overleaf and internal team review.

## Import into Overleaf

1. In Overleaf, choose **New Project > Upload Project**.
2. Upload the ZIP file containing this directory.
3. If Overleaf asks for the main document, select `main.tex`.
4. Use the **pdfLaTeX** compiler. Overleaf should run BibTeX automatically.

The canonical manuscript source is `paper_body.tex`. The small `main.tex`
wrapper enables the official anonymous ICLR style. `compiled_submission.pdf`
is included as a verified reference rendering for teammates who only need to
read the current version.

The package intentionally contains manuscript sources, bibliography, official
style, and referenced figures only. It does not include private machine paths,
training checkpoints, raw datasets, or internal review records.
